PS3 Read me text file

24-678: Computer Vision for Engineers
Ryan Wu
ID: weihuanw
PS3-2 Edge detection

Operating system: macOS Ventura 13.5.2
IDE you used to write and run your code: PyCharm 2023.1.4 (Community Edition)
The number of hours you spent to finish this problem: 6 hours.
 
